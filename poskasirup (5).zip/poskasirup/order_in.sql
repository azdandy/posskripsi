/*
 Navicat Premium Data Transfer

 Source Server         : mahasiswa
 Source Server Type    : MySQL
 Source Server Version : 100425
 Source Host           : localhost:3306
 Source Schema         : db_toko

 Target Server Type    : MySQL
 Target Server Version : 100425
 File Encoding         : 65001

 Date: 18/02/2023 00:48:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for order_in
-- ----------------------------
DROP TABLE IF EXISTS `order_in`;
CREATE TABLE `order_in`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_order` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tanggal_order` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'pembelian/bonus',
  `id_barang` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `harga_beli` decimal(11, 2) NULL DEFAULT NULL,
  `harga_jual` decimal(11, 2) NULL DEFAULT NULL,
  `qty` int(11) NULL DEFAULT NULL,
  `discount_qty` decimal(11, 2) NULL DEFAULT NULL,
  `discount_order` decimal(11, 2) NULL DEFAULT NULL,
  `harga_total` decimal(11, 2) NULL DEFAULT NULL,
  `pengirim` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `catatan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `tanggal_terima` date NULL DEFAULT NULL,
  `f_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'unpaid',
  `f_delete` int(11) NULL DEFAULT 0,
  `tanggal_input` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order_in
-- ----------------------------
INSERT INTO `order_in` VALUES (1, '0001-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR004', 5000.00, 7500.00, 200, 0.00, 0.00, 1000000.00, 'SP001', '', NULL, NULL, 0, '2023-01-19 08:58:21');
INSERT INTO `order_in` VALUES (2, '0001-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR001', 5000.00, 7000.00, 200, 0.00, 0.00, 1000000.00, 'SP001', '', NULL, NULL, 0, '2023-01-19 08:58:21');
INSERT INTO `order_in` VALUES (3, '0001-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR003', 200000.00, 230000.00, 200, 0.00, 0.00, 40000000.00, 'SP001', '', NULL, NULL, 0, '2023-01-19 08:58:21');
INSERT INTO `order_in` VALUES (4, '0002-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR007', 999.00, 999.00, 200, 99.00, 154000.00, 26000.00, 'SP003', 'pembelian 2', NULL, NULL, 0, '2023-01-19 09:00:08');
INSERT INTO `order_in` VALUES (5, '0002-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR005', 222.00, 222.00, 200, 22.00, 154000.00, -114000.00, 'SP003', 'pembelian 2', NULL, NULL, 0, '2023-01-19 09:00:08');
INSERT INTO `order_in` VALUES (6, '0002-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR004', 5000.00, 7500.00, 60, 0.00, 154000.00, 146000.00, 'SP003', 'pembelian 2', NULL, NULL, 0, '2023-01-19 09:00:08');
INSERT INTO `order_in` VALUES (7, '0002-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR002', 10000.00, 15000.00, 100, 0.00, 154000.00, 846000.00, 'SP003', 'pembelian 2', NULL, NULL, 0, '2023-01-19 09:00:08');
INSERT INTO `order_in` VALUES (8, '0002-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR001', 5000.00, 7000.00, 50, 0.00, 154000.00, 96000.00, 'SP003', 'pembelian 2', NULL, NULL, 0, '2023-01-19 09:00:08');
INSERT INTO `order_in` VALUES (9, '0003-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR003', 200000.00, 230000.00, 100, 0.00, 500000.00, 19500000.00, 'SP002', 'pembelian 3', '2023-02-17', 'paid', 0, '2023-01-19 09:01:05');
INSERT INTO `order_in` VALUES (10, '0003-PEM-19-01-23', '2023-01-19', 'pembelian', 'BR002', 10000.00, 15000.00, 100, 0.00, 500000.00, 500000.00, 'SP002', 'pembelian 3', '2023-02-17', 'paid', 0, '2023-01-19 09:01:05');
INSERT INTO `order_in` VALUES (13, '0004-PEM-22-01-23', '2023-01-22', 'pembelian', 'BR005', 222.00, 222.00, 200, 22.00, 20000.00, 20000.00, 'SP003', 'pembelian yang ke 4', NULL, NULL, 0, '2023-01-22 10:06:20');
INSERT INTO `order_in` VALUES (14, '0004-PEM-22-01-23', '2023-01-22', 'pembelian', 'BR004', 5000.00, 7500.00, 50, 0.00, 20000.00, 230000.00, 'SP003', 'pembelian yang ke 4', NULL, NULL, 0, '2023-01-22 10:06:20');

SET FOREIGN_KEY_CHECKS = 1;
